package Database;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

import flow.IProjectVariables;

public class Db 
{
	static Properties properties;
	private static Properties loadProperties(SCESession mySession) throws Exception 
	{
		String projectPath = mySession.getAbsoluteProjectFilePath();
		String propertiesPath = projectPath + "data/config.properties";

		FileReader reader = new FileReader(propertiesPath);
		Properties props = new Properties();
		props.load(reader);
		reader.close();
		return props;
	}

	// Establish a database connection
	public static Connection getDBConnection(SCESession mySession) 
	{
		try 
		{
			Properties props = loadProperties(mySession);
			String url = props.getProperty("url");
			String username = props.getProperty("username");
			String password = props.getProperty("password");
			String decrypt = Encrypt_Decrypt.decrypt(password);
			String driverClass = props.getProperty("Driver");

			Class.forName(driverClass);
			Connection connection = DriverManager.getConnection(url, username, decrypt);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection established successfully", mySession);
			return connection;

		} catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error establishing DB connection: " + e.getMessage(),
					mySession);
			e.printStackTrace();
			return null;
		}
	}
	
	// employeeid verification			
	public static boolean IsEmployeePresent(String E_ID, SCESession mySession) 
	{
		boolean isValid = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try 
		{			
			Properties properties = loadProperties(mySession);
			conn = getDBConnection(mySession);
			String E_IdVerify = properties.getProperty("E_ID");
			ps = conn.prepareStatement(E_IdVerify);
			ps.setInt(1, Integer.parseInt(E_ID));
			rs = ps.executeQuery();
			if (rs.next()) 
			{
				isValid = true;
			}
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Employee ID present: " + isValid, mySession);
	
		} catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error in E_ID: " + e.getMessage(),mySession);						
			e.printStackTrace();
			mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DB_VERIFY).setValue(true); 
			String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DB_VERIFY).getStringValue();  
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for E_ID: " + db , mySession);		
		}
		return isValid;
	}
	
	// segments verification			
	public static String getSegmentByEmployeeId(String eId, SCESession mySession) 
	{
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inside getSegmentByEmployeeId, EID: " + eId, mySession);		  
		String segmentValue = null;
	    Connection conn = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;

	    try {
	        Properties properties = loadProperties(mySession);
	        conn = getDBConnection(mySession);
	        String emp_segment = properties.getProperty("segments"); 
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "SegmentQuery :" +" "+ emp_segment, mySession);	 	   
	        ps = conn.prepareStatement(emp_segment);
	        ps.setInt(1, Integer.parseInt(eId));
	        rs = ps.executeQuery();

	        if (rs.next()) 
	        {
	            segmentValue = rs.getString("SEGMENTS");
	            mySession.getVariableField(IProjectVariables.ENGLISH, IProjectVariables.ENGLISH_FIELD_SEGM__TYPE).setValue(segmentValue); 			
	        }else 
	        {
	        	TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "No segment found for EID: " + eId, mySession);	        	  
	        }
	        	        
	    } catch (Exception e) 
	    {
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error fetching Segment: " + e.getMessage(), mySession);
	        e.printStackTrace();
	    }
	    return segmentValue;
	 }

	
	 public void CallHistory(String ucid, String dnisId, String ani, String SessionId, String ipAddress, String call_StartTime,
			 String call_EndTime, String Menudes, int Call_Duration, String ExitLocation, String endReason, SCESession mySession)
	 {
		 Connection connection = null;
	     PreparedStatement stmt = null;		
	     try 
	     {
	    	 Properties props = loadProperties(mySession);
			 String query = props.getProperty("db_query");
			 TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inserting values into CallHistory", mySession);
			 TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Query: " + query, mySession);
			 connection = getDBConnection(mySession);
			 if (connection == null) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection is null", mySession);
			}				
			 stmt = connection.prepareStatement(query);
			 if (stmt == null) 
			 {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Prepared Statement is null", mySession);
			 }	
				stmt.setString(1, ucid);
				stmt.setString(2, dnisId);
				stmt.setString(3, ani);
				stmt.setString(4, SessionId);
				stmt.setString(5, ipAddress);
				stmt.setString(6, call_StartTime);
				stmt.setString(7, call_EndTime);
				stmt.setString(8, Menudes);
				stmt.setInt(9, Call_Duration);
				stmt.setString(10, ExitLocation);
				stmt.setString(11, endReason);
				
	            int rows = stmt.executeUpdate();
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Rows inserted into call history table: " + rows, mySession);

				if (rows > 0) 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Datas gets storing in call history table", mySession);
				} else 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Datas not stored in call history", mySession);
				}

			} catch (Exception e) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Exception in saveAvayaIVRData method: " + e.getMessage(),
						mySession);
				e.printStackTrace();

				// Fallback to flat file
				FlatFile.writeToFlatFile(ucid, dnisId, ani, SessionId, ipAddress, call_StartTime, call_EndTime, Menudes, Call_Duration, ExitLocation, endReason, mySession);					
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Data written to FlatFile due to DB failure", mySession);
			}			
	 }
}

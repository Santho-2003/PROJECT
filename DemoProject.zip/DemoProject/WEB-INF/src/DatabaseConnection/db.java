package DatabaseConnection;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;

public class db 
{
	public static void main(String[] args) 
	{
		db d=new db();
		d.saveIVRData();
	}
	private String url;
	private String username;
	private String password;
	public void saveIVRData() {

try {
// Load JDBC driver
Class.forName("com.mysql.cj.jdbc.Driver");
FileReader file=new FileReader("C:\\Users\\santhoshini.b\\DemoProject\\data\\run.properties");
Properties properties=new Properties();
properties.load(file);

// Connect to DB
Connection conn = DriverManager.getConnection(url, username, password);
String url=properties.getProperty("url");
String username=properties.getProperty("username");
String password =properties.getProperty("password");
String query =properties.getProperty("query"); 
// Prepare SQL Insert statement
PreparedStatement stmt = conn.prepareStatement(query);
stmt.setInt(1,(101));                // Ucid
stmt.setInt(2,(20));                // Dnisid
stmt.setString(3, "Tamil");                           // Language
stmt.setInt(4,(3));        // Duration
stmt.setString(5,"102");                          // Starttime
stmt.setString(6, "103");                            // Endtime
stmt.setString(7, "2hrs");                       // callduration
stmt.setString(8, "Call ended successfully");                    // menuDes
stmt.setString(9,"AVAYA");                       // exitLocation
stmt.setInt(10, 12455);          // ipaddress
stmt.setInt(11, 203);          // sessionId
stmt.setString(12, "Customer Satisfied");                         // EndReason

stmt.executeUpdate();

stmt.close();
conn.close();

} catch (Exception e) 
{
e.printStackTrace();
}
	}
}




package DatabaseConnection;
import java.io.InputStream;
import java.util.Properties;
public class config 
{
private static Properties properties = new Properties();

	    static {
	        try {
	            InputStream input = config.class.getClassLoader().getResourceAsStream("dbconfig.properties");
	            if (input != null) {
	                properties.load(input);
	            } else {
	                throw new RuntimeException("dbconfig.properties not found in classpath");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public static String get(String key) {
	        return properties.getProperty(key);
	    }
	}

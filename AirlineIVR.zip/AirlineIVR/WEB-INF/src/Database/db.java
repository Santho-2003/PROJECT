package Database;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

import flow.IProjectVariables;

//import flow.IProjectVariables;


public class db 
{
	private static Properties loadProperties(SCESession mySession) throws Exception {
		String projectPath = mySession.getAbsoluteProjectFilePath();
		String propertiesPath = projectPath + "/data/Database.properties";

		FileReader reader = new FileReader(propertiesPath);
		Properties props = new Properties();
		props.load(reader);
		reader.close();
		return props;
	}

	// Establish a database connection
	public static Connection getDBConnection(SCESession mySession) 
	{
		try {
			Properties props = loadProperties(mySession);
			String url = props.getProperty("url");
			String username = props.getProperty("username");
			String password = props.getProperty("password");
			String driverClass = props.getProperty("Driver");

			Class.forName(driverClass);
			Connection connection = DriverManager.getConnection(url, username, password);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection established successfully", mySession);
			return connection;

		} catch (Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error establishing DB connection: " + e.getMessage(),
					mySession);
			e.printStackTrace();
			return null;
		}
	}

	// Validate ANI from session against AIRLINE_EMPLOYEE table
	public static boolean isValidANI(String ani, SCESession mySession) 
	{
		boolean isValid = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = getDBConnection(mySession);
			if (conn != null) {
				String sql = "SELECT 1 FROM AIRLINE_EMPLOYEE WHERE ANI = ?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, ani);
				rs = ps.executeQuery();

				if (rs.next()) 
				{
					isValid = true; // ANI found
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (Exception ex) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Error closing resources: " + ex.getMessage(), mySession);
			}
		}
		return isValid;
	}

	// employeeid verification
	public static boolean isEmployeeIdValid(String eId, SCESession mySession) 
	{
		boolean isValid = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = getDBConnection(mySession);
			String sql = "SELECT 1 FROM AIRLINE_EMPLOYEE WHERE E_ID = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(eId));
			rs = ps.executeQuery();

			if (rs.next()) 
			{
				isValid = true;
			}
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Employee ID Valid: " + isValid, mySession);

		} catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error validating E_ID: " + e.getMessage(),
					mySession);
			e.printStackTrace();
		} finally 
		{
			try 
			{
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (Exception ex) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing resources: " + ex.getMessage(), mySession);
				ex.printStackTrace();
			}
		}
		return isValid;
	}
	
	//pin number verification
	public static boolean isPinNoValid(String eId, String pin, SCESession mySession) 
	{
		boolean isValid = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = getDBConnection(mySession);
			String sql = "SELECT 1 FROM AIRLINE_EMPLOYEE WHERE E_ID = ? AND PIN = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(eId));
			ps.setInt(2, Integer.parseInt(pin));
			rs = ps.executeQuery();

			if (rs.next()) 
			{
				isValid = true;
			}
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "PinValid for employee id:" + isValid, mySession);

		} catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error validating PIN for Employeeid: " + e.getMessage(),
					mySession);
			e.printStackTrace();
		} finally 
		{
			try 
			{
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (Exception ex) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing resources: " + ex.getMessage(), mySession);
				ex.printStackTrace();
			}
		}
		return isValid;
	}

	// otp generation
	public static String generateOTP(String empId, SCESession mySession) {
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "generateOTP called with E_ID: " + empId, mySession);

		String otp = String.format("%06d", (int) (Math.random() * 1000000));
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = getDBConnection(mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection for OTP successful", mySession);
//  
//            // Delete old OTP if exists
//            String deleteSql = "DELETE FROM OTP WHERE E_ID = ?";
//            ps = conn.prepareStatement(deleteSql);
//            ps.setString(1, empId);
//            int deleted = ps.executeUpdate();
//            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Old OTP deleted count: " + deleted, mySession);
//            ps.close();
//            
//            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Attempting OTP insert for E_ID: " + empId + ", OTP: " + otp, mySession);

			// Insert new OTP
			String Sql = "INSERT INTO OTP (E_ID, OTP, TIMESTAMP) VALUES (?, ?, GETDATE())";
			ps = conn.prepareStatement(Sql);
			ps.setString(1, empId);
			ps.setString(2, otp);
			int inserted = ps.executeUpdate();
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inserted OTP rows: " + inserted + " | OTP: " + otp,
					mySession);

		} catch (Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error storing OTP: " + e.getMessage(), mySession);
			e.printStackTrace();
			otp = null;
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "The OTP GENERATING Statements closed", mySession);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return otp;
	}

	// otp verification
	public static boolean verifyOTP(String empId, String otp, SCESession mySession) 
	{
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inside db.verifyOTP method", mySession);
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "verifyOTP called with E_ID: " + empId + " and OTP: " + otp, mySession);
				
		boolean isValid = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			conn = getDBConnection(mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection for OTP verification successful", mySession);

			String sql = "SELECT * FROM OTP WHERE E_ID = ? AND OTP = ? AND DATEDIFF(MINUTE, TIMESTAMP, GETDATE()) <= 1";
			ps = conn.prepareStatement(sql);
			ps.setString(1, empId);
			ps.setString(2, otp);
			rs = ps.executeQuery();

			if (rs.next()) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "OTP match found in DB for E_ID:" + empId, mySession);
				isValid = true;
			} else {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "No matching OTP found in DB for E_ID:" + empId,
						mySession);
			}
		} catch (Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error verifying OTP:" + e.getMessage(), mySession);
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "The OTP VERICATION Statements closed", mySession);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

		return isValid;
	}

	// tripdetatils verify
	public boolean getTripVerify(String E_ID, SCESession mySession) {
		boolean isValid = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {

			conn = getDBConnection(mySession);
			String sql = "SELECT 1 FROM AIRLINE_EMPLOYEE WHERE E_ID = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(E_ID));
			rs = ps.executeQuery();
			if (rs.next()) {
				isValid = true;
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Trip verified using employeeid", mySession);
			}
			rs.close();
			ps.close();
			conn.close();

		} catch (Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error in getTripVerify: " + e.getMessage(), mySession);
		}
		return isValid;
	}

//    // Trip Details - DB Access Code  

	public String getTrip(String empId, SCESession mySession) 
	{
	    Connection conn = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;

	    try {
	        conn = getDBConnection(mySession);
	        String sql = "SELECT ORGIN, DESTINATION, TRIP_STARTDATE, TIME, FLIGHTNO FROM E_TRIP WHERE E_ID = ?";
	        ps = conn.prepareStatement(sql);
	        ps.setString(1, empId);
	        rs = ps.executeQuery();

	        boolean found = false;
	        ArrayList<String> orginList  = new ArrayList<>();
	        ArrayList<String> destinationList   = new ArrayList<>();
	        ArrayList<String> dateList   = new ArrayList<>();
	        ArrayList<String> timeList   = new ArrayList<>();
	        ArrayList<String> flightList   = new ArrayList<>();      

	        mySession.getVariableField(IProjectVariables.TRIP_DETAILS, IProjectVariables.TRIP_DETAILS_FIELD_INDEX).setValue(0);
            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Trip Index initialized to 0", mySession);
            
	        while (rs.next())
	        {
	            found = true;
	                     
	            String orgin = rs.getString("ORGIN");
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DBorgin: " + orgin, mySession);

	            String destination = rs.getString("DESTINATION");
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DBdestination: " + destination, mySession);

	            String date = rs.getString("TRIP_STARTDATE");
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DBdate: " + date, mySession);

	            String time = rs.getString("TIME");
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DBtime: " + time, mySession);

	            String flight = rs.getString("FLIGHTNO");
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DBflight: " + flight, mySession);

	             orginList.add(orgin);	            
	             destinationList.add(destination);	           
	             dateList.add(date);	            
	             timeList.add(time);	            
	             flightList.add(flight);
	        }
	        mySession.getVariableField(IProjectVariables.VARIABLES,IProjectVariables.VARIABLES_FIELD_ORGIN).setValue(orginList); 
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "orginList" + Arrays.deepToString(orginList.toArray()), mySession);		
	         
	        mySession.getVariableField(IProjectVariables.VARIABLES,IProjectVariables.VARIABLES_FIELD_DESTINATION).setValue(destinationList);      
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "destinationList" + Arrays.deepToString(destinationList.toArray()), mySession);		
	        
	        mySession.getVariableField(IProjectVariables.VARIABLES,IProjectVariables.VARIABLES_FIELD_DATE).setValue(dateList);      
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "dateList" + Arrays.deepToString(dateList.toArray()), mySession);		
	        
	        mySession.getVariableField(IProjectVariables.VARIABLES,IProjectVariables.VARIABLES_FIELD_TIME).setValue(timeList);      
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "timeList" + Arrays.deepToString(timeList.toArray()), mySession);		
	        
	        mySession.getVariableField(IProjectVariables.VARIABLES,IProjectVariables.VARIABLES_FIELD_FLIGHT).setValue(flightList);      
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "flightList" + Arrays.deepToString(flightList.toArray()), mySession);		
	        
	        if (!found)
	        {
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "No trips found for empId: " + empId, mySession);
	        }

	    } catch (Exception e) 
	    {
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "DB Error: " + e.getMessage(), mySession);
	    } finally 
	    {
	        try { if (rs != null) rs.close(); } catch (Exception e) {}
	        try { if (ps != null) ps.close(); } catch (Exception e) {}
	        try { if (conn != null) conn.close(); } catch (Exception e) {}
	    }
	    return empId;
	}

	// Trip dates cancel 
	public List<String> getTripDatesCancel(String empId, SCESession mySession)
	{
	    List<String> tripDates = new ArrayList<>();
	    Connection conn = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    try 
	    {
	        conn = getDBConnection(mySession);
	        String sql = "SELECT TRIP_STARTDATE FROM E_TRIP WHERE E_ID = ?";
	        ps = conn.prepareStatement(sql);
	        ps.setString(1, empId);
	        rs = ps.executeQuery();

	        boolean found = false;
	        ArrayList<String[]> trip = new ArrayList<>();
	        
	        while (rs.next()) 
	        {
	        	found = true;

	        	String date = rs.getString("TRIP_STARTDATE");
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "canceldate: " + date, mySession);
	            
	            String[] trips = new String[] {date};
	            trip.add(trips);
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "canceltrip:" + Arrays.toString(trips), mySession);	       
	        }
            mySession.getVariableField(IProjectVariables.TRIP_DETAILS,IProjectVariables.TRIP_DETAILS_FIELD_TRIP_LIST).setValue(trip);      
	        
	        if (!found)
	        {
	            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "No trips found for empId: " + empId, mySession);
	        }

	    } catch (Exception e) 
	    {
	        e.printStackTrace();
	        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Exception in tripdates: " + tripDates, mySession);		                 	              
            
	    } finally
	    {
	        try { if (rs != null) rs.close(); } catch (Exception e) {}
	        try { if (ps != null) ps.close(); } catch (Exception e) {}
	        try { if (conn != null) conn.close(); } catch (Exception e) {}
	    }
	    return tripDates;
	}

	// canceldates
	public boolean cancelTripForDate(String empId, String date, SCESession mySession)
	{
		Connection conn = null;
		PreparedStatement ps = null;
		try 
		{
			conn = getDBConnection(mySession);
			String sql = "DELETE FROM E_TRIP WHERE E_ID = ? AND TRIP_STARTDATE = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, empId);
			ps.setString(2, date);
			int rows = ps.executeUpdate();
			return rows > 0;
		} catch (Exception e) 
		{
			e.printStackTrace();
			return false;
		}
	}

	public void saveAvayaIVRData(String ucid, String dnisId, String selected_option, String ani, String call_StartTime,
			String call_EndTime, String Trip_Details, String ExitLocation, String SessionId, String ipAddress,
			String endReason, int Call_Duration, SCESession mySession) {
		Connection connection = null;
		PreparedStatement stmt = null;

		try {
			Properties props = loadProperties(mySession);
			String query = props.getProperty("db_query");
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inserting values into airline_ivr", mySession);

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Query: " + query, mySession); // Added to log the query

			// Get DB connection
			connection = getDBConnection(mySession);
			if (connection == null) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection is null", mySession);
			}

			stmt = connection.prepareStatement(query);
			if (stmt == null) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Prepared Statement is null", mySession);
			}

			stmt.setString(1, ucid);
			stmt.setString(2, dnisId);
			stmt.setString(3, selected_option);
			stmt.setString(4, ani);
			stmt.setString(5, call_StartTime);
			stmt.setString(6, call_EndTime);
			stmt.setString(7, Trip_Details);
			stmt.setString(8, ExitLocation);
			stmt.setString(9, SessionId);
			stmt.setString(10, ipAddress);
			stmt.setString(11, endReason);
			stmt.setInt(12, Call_Duration);

			int rows = stmt.executeUpdate();
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Rows inserted into call history table: " + rows, mySession);

			if (rows > 0) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Datas gets storing in airline_ivr table", mySession);
			} else {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Datas not stored in airline table", mySession);
			}

		} catch (Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Exception in saveAvayaIVRData method: " + e.getMessage(),
					mySession);
			e.printStackTrace();

			// Fallback to flat file
			FlatFile.writeToFlatFile(ucid, dnisId, selected_option, ani, call_StartTime, call_EndTime, Trip_Details,
					ExitLocation, SessionId, ipAddress, endReason, Call_Duration, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Data written to FlatFile due to DB failure", mySession);
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing statement: " + e.getMessage(), mySession);
			}
			try {
				if (connection != null)
					connection.close();
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing connection: " + e.getMessage(), mySession);
			}
		}
	}
}

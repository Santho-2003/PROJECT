package Database;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

public class FlatFile 
{
	public static void writeToFlatFile(String ucid, String dnisId, String ani,String SessionId,String ipAddress,
            String callStart_Time, String callEnd_Time, String MenuDes, int CallDuration, String ExitLocation,       
             String endReason, String TripDates, String Confirmation, String CancelledDates, String NotCancelledDates, SCESession mySession) 
{

TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO,"Flatfile called", mySession);

try 
{
// Dynamically construct the path to the properties file
String projectPath = mySession.getAbsoluteProjectFilePath();
String propertiesFilePath = projectPath + "/data/Database.properties";

// Load properties from the file
Properties properties = new Properties();
FileReader reader = new FileReader(propertiesFilePath);
properties.load(reader);
reader.close();

// Get the folder path from properties
String folderPath = properties.getProperty("folderPath");

if (folderPath == null || folderPath.trim().isEmpty())
{
TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO,"Folderpath not found in property file", mySession);
return;
}

// Ensure the folder exists
File folder = new File(folderPath);
if (!folder.exists()) 
{
TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO,"Folder doesn't exist creating now...", mySession);
if (folder.mkdirs()) 
{
TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Folder created successfully", mySession);
} else 
{
TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Fail to create folder", mySession);
return;
}
}

// Create a unique filename
String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
String filePath = folderPath + "/CallHistory" + timestamp + ".txt";

// Write the flat file
FileWriter writer = new FileWriter(filePath, true);
String flat = String.join(",", ucid, dnisId, ani, SessionId, ipAddress, callStart_Time, callEnd_Time, String.valueOf(CallDuration),
 MenuDes, ExitLocation, endReason, TripDates, Confirmation, CancelledDates, NotCancelledDates);
writer.write(flat + "\n");
writer.close();

TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Data Written to"+filePath, mySession);

} catch (Exception e)
{
e.printStackTrace();
TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Fail to create flatfile", mySession);
}       
}
}

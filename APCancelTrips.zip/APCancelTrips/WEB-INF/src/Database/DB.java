package Database;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

import flow.IProjectVariables;

public class DB 
{
	static Properties properties;
	private static Properties loadProperties(SCESession mySession) throws Exception 
	{
		String projectPath = mySession.getAbsoluteProjectFilePath();
		String propertiesPath = projectPath + "data/Database.properties";

		FileReader reader = new FileReader(propertiesPath);
		Properties props = new Properties();
		props.load(reader);
		reader.close();
		return props;
	}

	// Establish a database connection
	public static Connection getDBConnection(SCESession mySession) 
	{
		try {
			Properties props = loadProperties(mySession);
			String url = props.getProperty("url");
			String username = props.getProperty("username");
			String password = props.getProperty("password");
			String decrypt = Enc_Dec.decrypt(password);
			String driverClass = props.getProperty("Driver");

			Class.forName(driverClass);
			Connection connection = DriverManager.getConnection(url, username, decrypt);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection established successfully", mySession);
			return connection;

		} catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error establishing DB connection: " + e.getMessage(),
					mySession);
			e.printStackTrace();
			return null;
		}
	}

	//verfiy ani
	public static boolean isVerifiedANI(String ani, SCESession mySession) 
	{
		boolean isValid = false;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = getDBConnection(mySession);
			Properties properties = loadProperties(mySession); 
			if (conn != null) 
			{
				String AniVerify = properties.getProperty("Ani");
				ps = conn.prepareStatement(AniVerify);
				ps.setString(1, ani);
				rs = ps.executeQuery();

				if (rs.next()) 
				{
					isValid = true; 
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Valid Ani" + isValid, mySession);					
				}
				else 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Invalid Ani" + isValid, mySession);				
				}
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Error in Catch Block: " + e.getMessage(), mySession);	
			mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
			String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for ANI: " + db , mySession);	
		} 
			finally 
		{
			try 
			{
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (conn != null)
					conn.close();
			} catch (Exception ex) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Error closing resources: " + ex.getMessage(), mySession);
		    }
		}
		return isValid;
	}

	//Status verification
	public String checkStatus(SCESession mySession) 
	{
        String status = "";
        String mobileStr = mySession.getVariableField(IProjectVariables.SESSION,IProjectVariables.SESSION_FIELD_ANI).getStringValue();  
        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Status for ani" + mobileStr , mySession);	                     
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {        
        	conn = getDBConnection(mySession);
        	Properties properties = loadProperties(mySession); 
        	String StatusVerify = properties.getProperty("Active");
        	TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "StatusVerify" + StatusVerify , mySession);	                                
        	ps = conn.prepareStatement(StatusVerify);
            ps.setLong(1, Long.parseLong(mobileStr));
            rs = ps.executeQuery();

            if (rs.next()) 
            {
                status = rs.getString("STATUS"); 
                TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Employee Status" + status , mySession);	                     
            } else 
            {
            	TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Employee Status not found", mySession);	            	
                status = "not_found";
            }

        } catch (Exception e) 
        {
        	mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
			String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for STATUS: " + db , mySession);	
		
            mySession.getTraceOutput().writeln(ITraceInfo.TRACE_LEVEL_ERROR, "Error checking employee status: " + e.getMessage());
            status = "error";          
        }
        return status;
}
	
	// employeeid verification
		public static boolean isEmployeeIdValid(String eId, SCESession mySession) 
		{
			boolean isValid = false;
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;

			try 
			{
				Properties properties = loadProperties(mySession);
				conn = getDBConnection(mySession);
				String E_IdVerify = properties.getProperty("E_Id");
				ps = conn.prepareStatement(E_IdVerify);
				ps.setInt(1, Integer.parseInt(eId));
				rs = ps.executeQuery();
				if (rs.next()) 
				{
					isValid = true;
				}
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Employee ID Valid: " + isValid, mySession);

			} catch (Exception e) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error validating E_ID: " + e.getMessage(),mySession);						
				e.printStackTrace();
				mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
				String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for E_ID: " + db , mySession);	
			
			} finally 
			{
				try 
				{
					if (rs != null)
						rs.close();
					if (ps != null)
						ps.close();
					if (conn != null)
						conn.close();
				} catch (Exception ex) 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing resources: " + ex.getMessage(), mySession);
					ex.printStackTrace();
				}
			}
			return isValid;
		}		
		
		//pin number verification
		public static boolean isPinNoValid(String eId, String pin, SCESession mySession) 
		{
			boolean isValid = false;
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;

			try 
			{
				Properties properties = loadProperties(mySession);
				conn = getDBConnection(mySession);
				String pinverify= properties.getProperty("Pin");
				ps = conn.prepareStatement(pinverify);
				ps.setInt(1, Integer.parseInt(eId));
				ps.setInt(2, Integer.parseInt(pin));
				rs = ps.executeQuery();

				if (rs.next()) 
				{
					isValid = true;
				}
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "PinValid for employee id:" + isValid, mySession);
			} catch (Exception e) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error validating PIN for Employeeid: " + e.getMessage(),mySession);	
			    e.printStackTrace();
			    mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
				String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for Pin number: " + db , mySession);	
			
			} finally 
			{
				try 
				{
					if (rs != null)
						rs.close();
					if (ps != null)
						ps.close();
					if (conn != null)
						conn.close();
				} catch (Exception ex) 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing resources: " + ex.getMessage(), mySession);
					ex.printStackTrace();
				}
			}
			return isValid;
		}
		
		// otp generation
		public static String generateOTP(String empId, SCESession mySession)
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "generateOTP called with E_ID: " + empId, mySession);

			String otp = String.format("%06d", (int) (Math.random() * 1000000));
			Connection conn = null;
			PreparedStatement ps = null;
			try 
			{
				Properties properties = loadProperties(mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Properties loaded", mySession);

				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Connecting to DB...", mySession);
				conn = getDBConnection(mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection for OTP successful", mySession);
				
				// Insert new OTP
				String OTP = properties.getProperty("InsertOTP");
				ps = conn.prepareStatement(OTP);
				ps.setString(1, empId);
				ps.setString(2, otp);
				int inserted = ps.executeUpdate();
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inserted OTP rows: " + inserted + " | OTP: " + otp ,mySession);						

			} catch (Exception e) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error storing OTP: " + e.getMessage(), mySession);
				e.printStackTrace();
				otp = null;
			} finally 
			{
				try 
				{
					if (ps != null)
						ps.close();
					if (conn != null)
						conn.close();
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "The OTP Generating Statements closed", mySession);
				} catch (Exception ex) 
				{
					ex.printStackTrace();
				}
			}
			return otp;
		}

		// otp verification
		public static boolean verifyOTP(String empId, int otp, SCESession mySession) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inside db.verifyOTP method", mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "verifyOTP called with E_ID: " + empId + " and OTP: " + otp, mySession);
					
			boolean isValid = false;
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;

			try 
			{
				Properties properties = loadProperties(mySession);
				conn = getDBConnection(mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection for OTP verification successful", mySession);

				String OtpVerify = properties.getProperty("Otpverify");
				ps = conn.prepareStatement(OtpVerify);
				ps.setString(1, empId);
				ps.setInt(2, otp);
				rs = ps.executeQuery();

				if (rs.next()) 
				{
					isValid = true;
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "OTP match found in DB for E_ID:" + empId, mySession);				
				} else 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "No matching OTP found in DB for E_ID:" + empId ,mySession);
							
				}
			} catch (Exception e) 
			{
				mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
				String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for OTP: " + db , mySession);	
						
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error verifying OTP:" + e.getMessage(), mySession);
				e.printStackTrace();
			} finally 
			{
				try 
				{
					if (rs != null)
						rs.close();
					if (ps != null)
						ps.close();
					if (conn != null)
						conn.close();
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "The OTP VERICATION Statements closed", mySession);
				} catch (Exception ex) 
				{
					ex.printStackTrace();
				}
			}
			return isValid;
		}
		
		// available tripdates
		public boolean getTripVerify(String E_ID, SCESession mySession)
		{
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			 boolean hasTrips = false;

			try 
			{
				Properties properties = loadProperties(mySession);
				conn = getDBConnection(mySession);
				String tripverify = properties.getProperty("Tripverify");
				ps = conn.prepareStatement(tripverify);
				ps.setInt(1, Integer.parseInt(E_ID));
				rs = ps.executeQuery();
				if (rs.next()) 
				{
		            int count = rs.getInt(1);
		            hasTrips = count > 0;
		            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Trip count for E_ID " + E_ID + ": " + count, mySession);
		        }

		    } catch (Exception e) 
			{
		        
		    	mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
				String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for TripVerify: " + db , mySession);	
				
		    	TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error in hasTripsForEmployee: " + e.getMessage(), mySession);
		    } finally 
			{
		        try { if (rs != null) rs.close(); } catch (Exception e) {}
		        try { if (conn != null) conn.close(); } catch (Exception e) {}
		    }

		    return hasTrips;
		}
		
		// fetching tripdates
		public List<String> fetchTripDates(String empId, SCESession mySession) 
		{
		    Connection conn = null;
		    PreparedStatement ps = null;
		    ResultSet rs = null;
		    List<String> tripdates = new ArrayList<>();

		    try 
		    {		    	
		        Properties props = loadProperties(mySession);
		        String query = props.getProperty("Availabletrips");
		        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Query: " + query, mySession);
		        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Emp ID: " + empId, mySession);

		        conn = getDBConnection(mySession);
		        ps = conn.prepareStatement(query);
		        ps.setString(1, empId);

		        rs = ps.executeQuery();	      
	            while (rs.next()) 
	            {
	            	tripdates.add(rs.getString("TRIPSTARTDATE"));
	            }

	        } catch (Exception e) 
		    {
	        	mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
				String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for FetchingDates: " + db , mySession);	
				        	
	        	TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Exception in gettrips: " + e.getMessage(), mySession);
	            e.printStackTrace();
	        }
	        return tripdates;
	    }
		
		// cancel tripdates
		public static boolean cancelTrip(String empId, String tripDate, SCESession mySession) {
		    Connection conn = null;
		    PreparedStatement ps = null;
		    PreparedStatement updatePs = null;
		    ResultSet rs = null;
		    boolean success = false;

		    try {
		        Properties props = loadProperties(mySession);
		        String selectSQL = props.getProperty("Canceltrips");
		        String updateSQL = props.getProperty("Updatestatus");

		        conn = getDBConnection(mySession);
		        String[] tripDates = tripDate.split(",");
		        TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Processing tripDates: " + Arrays.toString(tripDates), mySession);

		        for (String date : tripDates) 
		        {
		            String currentDate = date.trim();
		            TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Checking trip: " + currentDate, mySession);

		            ps = conn.prepareStatement(selectSQL);
		            ps.setString(1, empId);
		            ps.setString(2, currentDate);
		            rs = ps.executeQuery();

		            if (rs.next() && "SCHEDULED".equalsIgnoreCase(rs.getString("TRIPSTATUS"))) 
		            {
		                updatePs = conn.prepareStatement(updateSQL);
		                updatePs.setString(1, empId);
		                updatePs.setString(2, currentDate);
		                int rowsUpdated = updatePs.executeUpdate();

		                if (rowsUpdated > 0) 
		                {
		                    success = true;
		                    TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "TripCancel " + currentDate + " cancelled successfully.", mySession);
		                } else 
		                {
		                    TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "TripCancel " + currentDate + " update failed.", mySession);
		                }
		                updatePs.close();
		            } else 
		            {
		                TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "TripCancel " + currentDate + " not found for cancellation.", mySession);
		            }
		            rs.close();
		            ps.close();
		        }

		    } catch (Exception e) 
		    {
		    	mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).setValue(true); 
				String db = mySession.getVariableField(IProjectVariables.VARIABLES, IProjectVariables.VARIABLES_FIELD_DBVERIFY).getStringValue();  
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "db failure for CancelDates: " + db , mySession);	
			
		    	TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "DB Error in cancelTrip(): " + e.getMessage(), mySession);
		    }
		    return success;
		}


		  public void saveAvayaIVRData(String ucid, String dnisId, String ani, String SessionId, String ipAddress, String call_StartTime,
		  String call_EndTime, String Menudes,int Call_Duration, String ExitLocation, String endReason, String TripDates, String Confirmation, String CancelledDates, String Notcancelleddates, SCESession mySession)
			
	    {
		Connection connection = null;
		PreparedStatement stmt = null;

		try {
			Properties props = loadProperties(mySession);
			String query = props.getProperty("db_query");
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Inserting values into CallHistory", mySession);

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Query: " + query, mySession);

			connection = getDBConnection(mySession);
			if (connection == null) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "DB connection is null", mySession);
			}

			stmt = connection.prepareStatement(query);
			if (stmt == null) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Prepared Statement is null", mySession);
			}

			stmt.setString(1, ucid);
			stmt.setString(2, dnisId);
			stmt.setString(3, ani);
			stmt.setString(4, SessionId);
			stmt.setString(5, ipAddress);
			stmt.setString(6, call_StartTime);
			stmt.setString(7, call_EndTime);
			stmt.setString(8, Menudes);
			stmt.setInt(9, Call_Duration);
			stmt.setString(10, ExitLocation);
			stmt.setString(11, endReason);
            stmt.setString(12, TripDates);
            stmt.setString(13, Confirmation);
            stmt.setString(14, CancelledDates);
            stmt.setString(15, Notcancelleddates);
			
            int rows = stmt.executeUpdate();
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Rows inserted into call history table: " + rows, mySession);

			if (rows > 0) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Datas gets storing in call history table", mySession);
			} else 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Datas not stored in call history", mySession);
			}

		} catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Exception in saveAvayaIVRData method: " + e.getMessage(),
					mySession);
			e.printStackTrace();

			// Fallback to flat file
			FlatFile.writeToFlatFile(ucid, dnisId, ani, SessionId, ipAddress, call_StartTime, call_EndTime, Menudes, Call_Duration, ExitLocation, endReason, TripDates, Confirmation, CancelledDates, Notcancelleddates, mySession);					
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, "Data written to FlatFile due to DB failure", mySession);
		} finally 
		{
			try 
			{
				if (stmt != null)
					stmt.close();
			} catch (Exception e) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing statement: " + e.getMessage(), mySession);
			}
			try 
			{
				if (connection != null)
					connection.close();
			} catch (Exception e) 
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, "Error closing connection: " + e.getMessage(), mySession);
			}
		}
	}
}
